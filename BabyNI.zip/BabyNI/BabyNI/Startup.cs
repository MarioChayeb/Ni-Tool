using BabyNI.Controllers;
using BabyNI.Data.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace BabyNI
{
    public class Startup
    {
        private readonly IConfiguration configuration;
        public LoadController _loadController;
        public LoadService _loadService;
        public ParserController _parserController;
        public ParsingService _parsingService;
        public FetchController _fetchcontroller;
        public FetchingService _fetchingservice; //test
       

        
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            //used  for watchers
            _loadService = new LoadService(configuration);
            _loadController = new LoadController(_loadService);
            _parsingService = new ParsingService(configuration);
            _parserController = new ParserController(_parsingService);
            _fetchingservice = new FetchingService(configuration);
            _fetchcontroller = new FetchController(_fetchingservice);
            
            //used  for watchers
            
            //////////////////////////////////////////////////////////
            

        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddCors();
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "BabyNI", Version = "v1" });
            });
            //configuring the loadservice.
            services.AddTransient<LoadService>();
            services.AddTransient<ParsingService>();
            services.AddTransient<AggregatingService>();
            services.AddTransient<FetchingService>();
            services.AddCors(options =>
            {
                options.AddPolicy(name: "AllowOrigin",
                    builder =>
                    {
                        builder.WithOrigins("https://localhost:4473", "http://localhost:4200")
                                            .AllowAnyHeader()
                                            .AllowAnyMethod()
                                            .AllowAnyOrigin();
                    });
            });


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "BabyNI v1"));
            }

            app.UseHttpsRedirection();

            app.UseRouting();
            //app.UseCors();
            app.UseCors("Allow-Origin");
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            Log.Logger = new LoggerConfiguration().CreateLogger();


            

















            ///////////////////////////////////LOADER WATCHER//////////////////////////////////////////////////


            FileSystemWatcher watcherLoader = new FileSystemWatcher();
            watcherLoader.Path = @"C:\Users\User\Desktop\ParsedFiles";
            watcherLoader.NotifyFilter = NotifyFilters.Attributes
            | NotifyFilters.CreationTime
            | NotifyFilters.DirectoryName
            | NotifyFilters.FileName
            | NotifyFilters.LastAccess
            | NotifyFilters.LastWrite
            | NotifyFilters.Security
            | NotifyFilters.Size;
            watcherLoader.Created += Loader_OnCreated;
            watcherLoader.Filter = Configuration.GetValue<string>("WatcherFilters:FileFilters");
            watcherLoader.EnableRaisingEvents = true;
            ///////////////////////////////////WATCHER LOADER//////////////////////////////////////////////////
            ///
            /// 
            ///////////////////////////////////PARSER WATCHER//////////////////////////////////////////////////
            FileSystemWatcher watcherparser = new FileSystemWatcher();
            watcherparser.Path = @"C:\Users\User\Desktop\ReceivedFiles";
            watcherparser.NotifyFilter = NotifyFilters.Attributes
            | NotifyFilters.CreationTime
            | NotifyFilters.DirectoryName
            | NotifyFilters.FileName
            | NotifyFilters.LastAccess
            | NotifyFilters.LastWrite
            | NotifyFilters.Security
            | NotifyFilters.Size;
            watcherparser.Created += Parser_OnCreated;
            watcherparser.Filter = Configuration.GetValue<string>("WatcherFilters:FileFilters");
            watcherparser.EnableRaisingEvents = true;

            ///////////////////////////////////LOG WATCHER/////////////////////////////////////////////////


            //    FileSystemWatcher logwatcher = new FileSystemWatcher();
            //    logwatcher.Path = @"C:\Users\User\Desktop\ParsedFilesTxt";
            //    logwatcher.NotifyFilter = NotifyFilters.Attributes
            //    | NotifyFilters.CreationTime
            //    | NotifyFilters.DirectoryName
            //    | NotifyFilters.FileName
            //    | NotifyFilters.LastAccess
            //    | NotifyFilters.LastWrite
            //    | NotifyFilters.Security
            //    | NotifyFilters.Size;
            //    logwatcher.Created += logwatcher_oncreated;
            //    logwatcher.Filter = "*.txt";
            //    logwatcher.EnableRaisingEvents = true;
        }


        public void Parser_OnCreated(object sender, FileSystemEventArgs e)
        {
            
           _parsingService.ParseFile(e.FullPath);
             

        }

        public void Loader_OnCreated(object sender, FileSystemEventArgs e)
        {
          
            _loadService.CopyData(e.FullPath);
          

        }

        //public void logwatcher_oncreated(object sender, FileSystemEventArgs e)
        //{

        //    _loadService.LogInfo(e.FullPath);


        //}


    }

}
